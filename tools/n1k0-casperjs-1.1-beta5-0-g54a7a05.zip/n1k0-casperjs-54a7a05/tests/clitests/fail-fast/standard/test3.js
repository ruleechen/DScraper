casper.test.begin('test 3', 1, function(test) {
    test.assert(true);
    test.done();
});
